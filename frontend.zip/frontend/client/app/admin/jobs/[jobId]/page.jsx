"use client";
import { useState, useEffect } from "react";
import axios from "axios";
import { ArrowLeft, Copy, Share2 } from "lucide-react";
import { showError, showSuccess } from "@/utils/toast";

export default function JobDetailPage({ params }) {
  const [job, setJob] = useState(null);
  const [similarJobs, setSimilarJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchJobDetails();
  }, [params.jobId]);

  const fetchJobDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/jobs/${params.jobId}`);
      setJob(response.data);
      
      // Fetch similar jobs (same department or location)
      try {
        const allJobsResponse = await axios.get("http://localhost:5000/api/jobs");
        const similar = allJobsResponse.data
          .filter(j => 
            j.id !== response.data.id && 
            (j.department === response.data.department || j.location === response.data.location) &&
            j.status === 'active'
          )
          .slice(0, 3);
        setSimilarJobs(similar);
      } catch (err) {
        console.log("Could not fetch similar jobs");
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error fetching job details:", error);
      showError("Failed to load job details");
      setLoading(false);
    }
  };

  const copyLink = () => {
    const url = `${window.location.origin}/admin/jobs/${params.jobId}`;
    navigator.clipboard.writeText(url);
    showSuccess("Link copied to clipboard");
  };

  const shareJob = () => {
    if (navigator.share) {
      navigator.share({
        title: job.job_title,
        text: `Check out this ${job.job_title} position at our company`,
        url: window.location.href
      });
    } else {
      copyLink();
    }
  };

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <p style={{ fontSize: "1rem", color: "#6b7280" }}>Loading job details...</p>
      </div>
    );
  }

  if (!job) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <p style={{ fontSize: "1rem", color: "#dc2626" }}>Job not found</p>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#f9fafb", padding: "2rem 1rem" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        {/* Header */}
        <div style={{ marginBottom: "2rem" }}>
          <button
            onClick={() => window.history.back()}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              backgroundColor: "transparent",
              border: "none",
              color: "#3b82f6",
              cursor: "pointer",
              fontSize: "1rem",
              fontWeight: "600",
              marginBottom: "1rem"
            }}
          >
            <ArrowLeft size={20} />
            Back to Jobs
          </button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: "2rem" }}>
          {/* Main Content */}
          <div>
            {/* Job Overview Section */}
            <div style={{
              backgroundColor: "#ffffff",
              borderRadius: "0.75rem",
              border: "1px solid #e5e7eb",
              padding: "2rem",
              marginBottom: "2rem",
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
            }}>
              <h1 style={{ fontSize: "2.5rem", fontWeight: "700", margin: "0 0 1.5rem 0", color: "#1f2937" }}>
                {job.job_title}
              </h1>

              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                gap: "2rem",
                marginBottom: "2rem",
                paddingBottom: "2rem",
                borderBottom: "1px solid #e5e7eb"
              }}>
                <div>
                  <p style={{ fontSize: "0.75rem", color: "#9ca3af", fontWeight: "700", margin: "0 0 0.5rem 0", textTransform: "uppercase", letterSpacing: "0.5px" }}>Location</p>
                  <p style={{ fontSize: "1rem", color: "#1f2937", fontWeight: "600", margin: 0 }}>{job.location}</p>
                </div>
                <div>
                  <p style={{ fontSize: "0.75rem", color: "#9ca3af", fontWeight: "700", margin: "0 0 0.5rem 0", textTransform: "uppercase", letterSpacing: "0.5px" }}>Job Type</p>
                  <p style={{ fontSize: "1rem", color: "#1f2937", fontWeight: "600", margin: 0 }}>{job.job_type || "-"}</p>
                </div>
                <div>
                  <p style={{ fontSize: "0.75rem", color: "#9ca3af", fontWeight: "700", margin: "0 0 0.5rem 0", textTransform: "uppercase", letterSpacing: "0.5px" }}>Experience</p>
                  <p style={{ fontSize: "1rem", color: "#1f2937", fontWeight: "600", margin: 0 }}>{job.experience_required || "-"}</p>
                </div>
                <div>
                  <p style={{ fontSize: "0.75rem", color: "#9ca3af", fontWeight: "700", margin: "0 0 0.5rem 0", textTransform: "uppercase", letterSpacing: "0.5px" }}>Salary</p>
                  <p style={{ fontSize: "1rem", color: "#1f2937", fontWeight: "600", margin: 0 }}>{job.salary_range || "-"}</p>
                </div>
              </div>

              <div>
                <p style={{ fontSize: "0.75rem", color: "#9ca3af", fontWeight: "700", margin: "0 0 0.5rem 0", textTransform: "uppercase", letterSpacing: "0.5px" }}>Department</p>
                <p style={{ fontSize: "1rem", color: "#1f2937", fontWeight: "600", margin: 0 }}>{job.department}</p>
              </div>
            </div>

            {/* About This Role */}
            {job.job_description && (
              <div style={{
                backgroundColor: "#ffffff",
                borderRadius: "0.75rem",
                border: "1px solid #e5e7eb",
                padding: "2rem",
                marginBottom: "2rem",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}>
                <h2 style={{ fontSize: "1.25rem", fontWeight: "700", margin: "0 0 1rem 0", color: "#1f2937" }}>
                  About This Role
                </h2>
                <div style={{ color: "#4b5563", lineHeight: "1.8", whiteSpace: "pre-wrap", fontSize: "0.95rem" }}>
                  {job.job_description}
                </div>
              </div>
            )}

            {/* Key Responsibilities */}
            {job.responsibilities && (
              <div style={{
                backgroundColor: "#ffffff",
                borderRadius: "0.75rem",
                border: "1px solid #e5e7eb",
                padding: "2rem",
                marginBottom: "2rem",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}>
                <h2 style={{ fontSize: "1.25rem", fontWeight: "700", margin: "0 0 1rem 0", color: "#1f2937" }}>
                  Key Responsibilities
                </h2>
                <div style={{ color: "#4b5563", lineHeight: "1.8", whiteSpace: "pre-wrap", fontSize: "0.95rem" }}>
                  {job.responsibilities}
                </div>
              </div>
            )}

            {/* Qualifications */}
            {job.qualifications && (
              <div style={{
                backgroundColor: "#ffffff",
                borderRadius: "0.75rem",
                border: "1px solid #e5e7eb",
                padding: "2rem",
                marginBottom: "2rem",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}>
                <h2 style={{ fontSize: "1.25rem", fontWeight: "700", margin: "0 0 1rem 0", color: "#1f2937" }}>
                  Key Qualifications
                </h2>
                <div style={{ color: "#4b5563", lineHeight: "1.8", whiteSpace: "pre-wrap", fontSize: "0.95rem" }}>
                  {job.qualifications}
                </div>
              </div>
            )}

            {/* Benefits */}
            {job.benefits && (
              <div style={{
                backgroundColor: "#ffffff",
                borderRadius: "0.75rem",
                border: "1px solid #e5e7eb",
                padding: "2rem",
                marginBottom: "2rem",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}>
                <h2 style={{ fontSize: "1.25rem", fontWeight: "700", margin: "0 0 1rem 0", color: "#1f2937" }}>
                  Benefits & Perks
                </h2>
                <div style={{ color: "#4b5563", lineHeight: "1.8", whiteSpace: "pre-wrap", fontSize: "0.95rem" }}>
                  {job.benefits}
                </div>
              </div>
            )}

            {/* Similar Positions */}
            {similarJobs.length > 0 && (
              <div style={{
                backgroundColor: "#ffffff",
                borderRadius: "0.75rem",
                border: "1px solid #e5e7eb",
                padding: "2rem",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}>
                <h2 style={{ fontSize: "1.25rem", fontWeight: "700", margin: "0 0 1.5rem 0", color: "#1f2937" }}>
                  Similar Positions
                </h2>
                <div style={{ display: "grid", gap: "1rem" }}>
                  {similarJobs.map((similarJob) => (
                    <div
                      key={similarJob.id}
                      onClick={() => window.location.href = `/admin/jobs/${similarJob.id}`}
                      style={{
                        padding: "1rem",
                        border: "1px solid #e5e7eb",
                        borderRadius: "0.5rem",
                        cursor: "pointer",
                        transition: "all 0.3s",
                        backgroundColor: "#f9fafb"
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = "#f3f4f6";
                        e.currentTarget.style.borderColor = "#3b82f6";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = "#f9fafb";
                        e.currentTarget.style.borderColor = "#e5e7eb";
                      }}
                    >
                      <h3 style={{ fontSize: "1rem", fontWeight: "600", margin: "0 0 0.5rem 0", color: "#1f2937" }}>
                        {similarJob.job_title}
                      </h3>
                      <p style={{ fontSize: "0.875rem", color: "#6b7280", margin: 0 }}>
                        {similarJob.department} • {similarJob.location}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div>
            {/* Ready to Apply? */}
            <div style={{
              backgroundColor: "#ffffff",
              borderRadius: "0.75rem",
              border: "1px solid #e5e7eb",
              padding: "1.5rem",
              marginBottom: "1.5rem",
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
              position: "sticky",
              top: "2rem"
            }}>
              <h3 style={{ fontSize: "1rem", fontWeight: "700", margin: "0 0 1rem 0", color: "#1f2937" }}>
                Ready to Apply?
              </h3>
              <p style={{ fontSize: "0.875rem", color: "#6b7280", margin: "0 0 1rem 0", lineHeight: "1.5" }}>
                Click the button below to apply on LinkedIn for this exciting opportunity.
              </p>
              <button
                style={{
                  width: "100%",
                  backgroundColor: "#f97316",
                  color: "#fff",
                  border: "none",
                  padding: "0.75rem 1.5rem",
                  borderRadius: "0.5rem",
                  cursor: "pointer",
                  fontWeight: "600",
                  fontSize: "1rem",
                  transition: "all 0.3s"
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#ea580c"}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#f97316"}
              >
                Apply Now on LinkedIn
              </button>
            </div>

            {/* Share This Job */}
            <div style={{
              backgroundColor: "#ffffff",
              borderRadius: "0.75rem",
              border: "1px solid #e5e7eb",
              padding: "1.5rem",
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
            }}>
              <h3 style={{ fontSize: "1rem", fontWeight: "700", margin: "0 0 1rem 0", color: "#1f2937" }}>
                Share This Job
              </h3>

              <button
                onClick={copyLink}
                style={{
                  width: "100%",
                  backgroundColor: "#f3f4f6",
                  color: "#1f2937",
                  border: "1px solid #e5e7eb",
                  padding: "0.75rem",
                  borderRadius: "0.5rem",
                  cursor: "pointer",
                  fontWeight: "600",
                  fontSize: "0.875rem",
                  marginBottom: "0.75rem",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "0.5rem",
                  transition: "all 0.3s"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "#e5e7eb";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "#f3f4f6";
                }}
              >
                <Copy size={16} />
                Copy Link
              </button>

              <button
                onClick={shareJob}
                style={{
                  width: "100%",
                  backgroundColor: "#3b82f6",
                  color: "#fff",
                  border: "none",
                  padding: "0.75rem",
                  borderRadius: "0.5rem",
                  cursor: "pointer",
                  fontWeight: "600",
                  fontSize: "0.875rem",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "0.5rem",
                  transition: "all 0.3s"
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#2563eb"}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#3b82f6"}
              >
                <Share2 size={16} />
                Share
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
