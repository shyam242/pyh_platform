"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { Trash2, AlertCircle } from "lucide-react";
import { showError, showSuccess } from "@/utils/toast";

export default function BulkCandidatesPage() {
  const router = useRouter();
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCandidates, setSelectedCandidates] = useState(new Set());
  const [selectAll, setSelectAll] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchBulkCandidates();
  }, []);

  const fetchBulkCandidates = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const response = await axios.get(
        "http://localhost:5000/api/admin/bulk-candidates",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setCandidates(response.data || []);
    } catch (error) {
      console.error("Error fetching bulk candidates:", error);
      showError("Failed to fetch bulk candidates");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectCandidate = (id) => {
    const newSelected = new Set(selectedCandidates);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedCandidates(newSelected);
    setSelectAll(false);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedCandidates(new Set());
      setSelectAll(false);
    } else {
      const allIds = new Set(candidates.map(c => c.id));
      setSelectedCandidates(allIds);
      setSelectAll(true);
    }
  };

  const handleDeleteCandidate = async (id) => {
    if (!window.confirm("Delete this candidate?")) return;

    try {
      const token = localStorage.getItem("token");
      await axios.delete(
        `http://localhost:5000/api/admin/bulk-candidates/${id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setCandidates(candidates.filter(c => c.id !== id));
      setSelectedCandidates(prev => {
        const updated = new Set(prev);
        updated.delete(id);
        return updated;
      });
      showSuccess("Candidate deleted successfully");
    } catch (error) {
      console.error("Error deleting candidate:", error);
      showError("Failed to delete candidate");
    }
  };

  const handleBulkDelete = async () => {
    if (selectedCandidates.size === 0) {
      showError("Please select candidates to delete");
      return;
    }

    if (!window.confirm(`Delete ${selectedCandidates.size} candidates?`)) return;

    try {
      setDeleting(true);
      const token = localStorage.getItem("token");
      
      for (const id of selectedCandidates) {
        await axios.delete(
          `http://localhost:5000/api/admin/bulk-candidates/${id}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }

      setCandidates(candidates.filter(c => !selectedCandidates.has(c.id)));
      setSelectedCandidates(new Set());
      setSelectAll(false);
      showSuccess(`${selectedCandidates.size} candidates deleted successfully`);
    } catch (error) {
      console.error("Error bulk deleting candidates:", error);
      showError("Failed to delete some candidates");
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-linear-to-br from-blue-50 via-slate-50 to-indigo-100 p-8 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          <p className="mt-4 text-gray-600">Loading candidates...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Bulk Uploaded Candidates</h1>
          <p className="text-slate-600">Manage candidates uploaded via CSV</p>
        </div>

        {/* Selection Controls */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectAll}
                  onChange={handleSelectAll}
                  className="w-5 h-5 rounded border-gray-300"
                />
                <span className="text-sm font-medium text-gray-700">
                  {selectAll ? "Deselect All" : "Select All"}
                </span>
              </label>
              <span className="text-sm text-gray-600">
                {selectedCandidates.size} selected
              </span>
            </div>

            {selectedCandidates.size > 0 && (
              <button
                onClick={handleBulkDelete}
                disabled={deleting}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
              >
                <Trash2 size={18} />
                Delete Selected ({selectedCandidates.size})
              </button>
            )}
          </div>
        </div>

        {/* Candidates Grid */}
        {candidates.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <AlertCircle size={48} className="mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600 text-lg">No bulk candidates uploaded yet</p>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {candidates.map((candidate) => (
              <div
                key={candidate.id}
                onClick={() => router.push(`/bulk-candidates/${candidate.id}`)}
                className="group flex h-full cursor-pointer flex-col justify-between overflow-hidden rounded-[32px] border border-slate-200 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              >
                <div>
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <h3 className="truncate text-xl font-semibold text-slate-900">
                        {candidate.name}
                      </h3>
                      <p className="mt-2 text-sm leading-6 text-slate-500">
                        {candidate.email}
                      </p>
                    </div>
                    <label className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-slate-500 transition-colors duration-200 hover:border-slate-300">
                      <input
                        type="checkbox"
                        checked={selectedCandidates.has(candidate.id)}
                        onClick={(e) => e.stopPropagation()}
                        onChange={() => handleSelectCandidate(candidate.id)}
                        className="h-4 w-4 rounded border-slate-300 text-slate-700"
                      />
                    </label>
                  </div>

                  {candidate.skills && (
                    <div className="mt-6">
                      <p className="text-[10px] uppercase tracking-[0.35em] text-slate-400 mb-3">
                        Skills
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {typeof candidate.skills === "string"
                          ? candidate.skills.split(",").slice(0, 5).map((skill, idx) => (
                              <span
                                key={idx}
                                className="inline-flex items-center rounded-full bg-sky-100 px-3 py-1 text-xs font-semibold text-slate-800"
                              >
                                {skill.trim()}
                              </span>
                            ))
                          : null}
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-6 border-t border-slate-200 pt-5 text-sm text-slate-600">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.35em] text-slate-400">
                        Company
                      </p>
                      <p className="mt-1 font-medium text-slate-900">
                        {candidate.current_company_name || "—"}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.35em] text-slate-400">
                        Experience
                      </p>
                      <p className="mt-1 font-medium text-slate-900">
                        {candidate.experience ? `${candidate.experience} yrs` : "—"}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-[10px] uppercase tracking-[0.35em] text-slate-400">
                      Source
                    </p>
                    <p className="mt-1 inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                      Bulk upload
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
