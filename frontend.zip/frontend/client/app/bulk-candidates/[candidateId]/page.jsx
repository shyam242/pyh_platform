"use client";
import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import axios from "axios";
import { ArrowLeft, Download } from "lucide-react";
import { showError } from "@/utils/toast";

export default function BulkCandidateDetailPage() {
  const { candidateId } = useParams();
  const router = useRouter();
  const [candidate, setCandidate] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCandidateDetails();
  }, [candidateId]);

  const fetchCandidateDetails = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const response = await axios.get(
        `http://localhost:5000/api/admin/bulk-candidates`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      
      // Find the candidate with matching ID
      const found = response.data.find(c => c.id === parseInt(candidateId));
      if (found) {
        setCandidate(found);
      } else {
        showError("Candidate not found");
        router.back();
      }
    } catch (error) {
      console.error("Error fetching candidate:", error);
      showError("Failed to load candidate details");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-linear-to-br from-blue-50 to-indigo-100 p-8 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          <p className="mt-4 text-gray-600">Loading candidate details...</p>
        </div>
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="min-h-screen bg-linear-to-br from-blue-50 via-slate-50 to-indigo-100 p-8 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 text-lg">Candidate not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-8">
          <button
            onClick={() => router.back()}
            className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors duration-200 hover:bg-slate-800"
          >
            <ArrowLeft size={18} />
            Candidate Details
          </button>

          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center rounded-full bg-emerald-100 px-4 py-2 text-sm font-semibold text-emerald-800">
              Bulk Upload
            </span>
            {candidate.technical_skills && (
              <span className="inline-flex items-center rounded-full bg-sky-100 px-4 py-2 text-sm font-semibold text-sky-700">
                {candidate.technical_skills.split(",")[0]?.trim() || "Technical"}
              </span>
            )}
            {candidate.resume_link && (
              <a
                href={candidate.resume_link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors duration-200 hover:bg-slate-800"
              >
                <Download size={16} />
                Download CV
              </a>
            )}
          </div>
        </div>

        <div className="grid gap-6 xl:grid-cols-[1.4fr_0.6fr]">
          <div className="space-y-6">
            <section className="rounded-[32px] bg-white p-8 shadow-sm border border-slate-200">
              <div className="flex flex-col gap-6 xl:flex-row xl:items-center xl:justify-between">
                <div className="min-w-0">
                  <h1 className="text-4xl font-semibold text-slate-900 mb-2 truncate">
                    {candidate.name || "Candidate"}
                  </h1>
                  {candidate.role && <p className="text-lg text-slate-600">{candidate.role}</p>}
                </div>

                <div className="grid gap-3 sm:auto-cols-max sm:grid-flow-col">
                  <div className="rounded-3xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700">
                    {candidate.email || "No email provided"}
                  </div>
                  <div className="rounded-3xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700">
                    {candidate.contact || "No phone provided"}
                  </div>
                </div>
              </div>
            </section>

            <section className="rounded-[32px] bg-white p-8 shadow-sm border border-slate-200">
              <h2 className="text-xl font-semibold text-slate-900 mb-6">Professional Details</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                {candidate.current_company_name && (
                  <div className="rounded-3xl bg-slate-50 p-5">
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Current Company</p>
                    <p className="font-medium text-slate-900">{candidate.current_company_name}</p>
                  </div>
                )}
                {candidate.experience && (
                  <div className="rounded-3xl bg-slate-50 p-5">
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Experience</p>
                    <p className="font-medium text-slate-900">{candidate.experience} years</p>
                  </div>
                )}
                {candidate.current_ctc && (
                  <div className="rounded-3xl bg-slate-50 p-5">
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Current CTC</p>
                    <p className="font-medium text-slate-900">{candidate.current_ctc}</p>
                  </div>
                )}
                {candidate.expected_ctc && (
                  <div className="rounded-3xl bg-slate-50 p-5">
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Expected CTC</p>
                    <p className="font-medium text-slate-900">{candidate.expected_ctc}</p>
                  </div>
                )}
                {candidate.current_location && (
                  <div className="rounded-3xl bg-slate-50 p-5">
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Current Location</p>
                    <p className="font-medium text-slate-900">{candidate.current_location}</p>
                  </div>
                )}
                {candidate.preferred_location && (
                  <div className="rounded-3xl bg-slate-50 p-5">
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Preferred Location</p>
                    <p className="font-medium text-slate-900">{candidate.preferred_location}</p>
                  </div>
                )}
              </div>
            </section>

            {(candidate.skills || candidate.technical_skills || candidate.soft_skills) && (
              <section className="rounded-[32px] bg-white p-8 shadow-sm border border-slate-200">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Skills</h2>
                <div className="space-y-5">
                  {candidate.skills && (
                    <div>
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-3">Core Skills</p>
                      <div className="flex flex-wrap gap-2">
                        {typeof candidate.skills === "string"
                          ? candidate.skills.split(",").map((skill, idx) => (
                              <span key={`core-${idx}`} className="rounded-full bg-sky-100 px-3 py-1 text-sm font-medium text-sky-700">
                                {skill.trim()}
                              </span>
                            ))
                          : null}
                      </div>
                    </div>
                  )}
                  {candidate.technical_skills && (
                    <div>
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-3">Technical Skills</p>
                      <div className="flex flex-wrap gap-2">
                        {typeof candidate.technical_skills === "string"
                          ? candidate.technical_skills.split(",").map((skill, idx) => (
                              <span key={`tech-${idx}`} className="rounded-full bg-violet-100 px-3 py-1 text-sm font-medium text-violet-700">
                                {skill.trim()}
                              </span>
                            ))
                          : null}
                      </div>
                    </div>
                  )}
                  {candidate.soft_skills && (
                    <div>
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-3">Soft Skills</p>
                      <div className="flex flex-wrap gap-2">
                        {typeof candidate.soft_skills === "string"
                          ? candidate.soft_skills.split(",").map((skill, idx) => (
                              <span key={`soft-${idx}`} className="rounded-full bg-emerald-100 px-3 py-1 text-sm font-medium text-emerald-700">
                                {skill.trim()}
                              </span>
                            ))
                          : null}
                      </div>
                    </div>
                  )}
                </div>
              </section>
            )}
          </div>

          <div className="space-y-6">
            {(candidate.notice_period || candidate.offer_in_hand || candidate.reason_for_change || candidate.highest_qualification) && (
              <section className="rounded-[32px] bg-white p-8 shadow-sm border border-slate-200">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Additional Information</h2>
                <div className="grid gap-4">
                  {candidate.notice_period && (
                    <div className="rounded-3xl bg-slate-50 p-5">
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Notice Period</p>
                      <p className="font-medium text-slate-900">{candidate.notice_period}</p>
                    </div>
                  )}
                  {candidate.offer_in_hand && (
                    <div className="rounded-3xl bg-slate-50 p-5">
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Offer In Hand</p>
                      <p className="font-medium text-slate-900">{candidate.offer_in_hand}</p>
                    </div>
                  )}
                  {candidate.reason_for_change && (
                    <div className="rounded-3xl bg-slate-50 p-5">
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Reason for Change</p>
                      <p className="font-medium text-slate-900">{candidate.reason_for_change}</p>
                    </div>
                  )}
                  {candidate.highest_qualification && (
                    <div className="rounded-3xl bg-slate-50 p-5">
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400 mb-2">Qualification</p>
                      <p className="font-medium text-slate-900">{candidate.highest_qualification}</p>
                    </div>
                  )}
                </div>
              </section>
            )}

            {(candidate.linkedin || candidate.resume_link) && (
              <section className="rounded-[32px] bg-white p-8 shadow-sm border border-slate-200">
                <h2 className="text-xl font-semibold text-slate-900 mb-6">Links</h2>
                <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                  {candidate.linkedin && (
                    <a
                      href={candidate.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-full bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-800 hover:bg-blue-200 transition-colors"
                    >
                      View LinkedIn Profile
                    </a>
                  )}
                  {candidate.resume_link && (
                    <a
                      href={candidate.resume_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-200 transition-colors"
                    >
                      <Download size={16} />
                      View Resume
                    </a>
                  )}
                </div>
              </section>
            )}

            <div className="rounded-[32px] bg-slate-50 p-6 text-center text-sm text-slate-500">
              This candidate was bulk uploaded and was not referred by anyone.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
