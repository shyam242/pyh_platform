"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Edit2, Upload, CheckCircle2, Plus, X } from "lucide-react";
import { showSuccess, showError } from "@/utils/toast";

const AVAILABLE_SKILLS = ["React", "Node.js", "Python", "Java", "AWS", "UI/UX", "TypeScript", "MongoDB"];

export default function CandidateProfilePage() {
  const router = useRouter();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [resume, setResume] = useState(null);
  const [skills, setSkills] = useState([]);
  const [customSkill, setCustomSkill] = useState("");
  const [verifyLoading, setVerifyLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        router.push("/signin");
        return;
      }

      const res = await fetch("http://localhost:5000/api/profile/candidate", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error("Failed to fetch profile");

      const data = await res.json();
      setProfile(data);
    } catch (err) {
      showError(err.message || "Failed to load profile");
    } finally {
      setLoading(false);
    }
  };

  const toggleSkill = (s) => {
    setSkills((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  };

  const addSkill = () => {
    if (customSkill.trim() && !skills.includes(customSkill.trim())) {
      setSkills([...skills, customSkill.trim()]);
      setCustomSkill("");
    }
  };

  const removeSkill = (s) => {
    setSkills(skills.filter((x) => x !== s));
  };

  const submitVerification = async () => {
    if (!resume) return showError("Upload resume first");
    if (skills.length === 0) return showError("Select at least one skill");

    setVerifyLoading(true);

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        showError("Please sign in again.");
        router.push("/signin");
        return;
      }
      const fd = new FormData();
      fd.append("file", resume);
      fd.append("skills", JSON.stringify(skills));

      const res = await fetch("http://localhost:5000/api/profile/verify", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: fd
      });

      if (!res.ok) {
        const rawText = await res.text();
        let parsed;
        try {
          parsed = JSON.parse(rawText);
        } catch (e) {
          parsed = null;
        }
        const bodyText = parsed?.message || parsed?.error || rawText;
        if (res.status === 404 || res.status === 405 || /Cannot POST/i.test(rawText)) {
          throw new Error(
            `Backend route not found: POST http://localhost:5000/api/profile/verify. Confirm the server defines this endpoint and accepts POST requests.`
          );
        }
        throw new Error(bodyText || `Verification failed (status ${res.status})`);
      }

      showSuccess("Profile verified successfully!");
      setResume(null);
      setSkills([]);
      const tokenRef = localStorage.getItem("token");
      if (tokenRef) await fetchProfile();
    } catch (err) {
      showError(err.message || "Verification failed");
    } finally {
      setVerifyLoading(false);
    }
  };

  const deleteProfile = async () => {
    if (!confirm("Are you sure you want to delete your profile? This action cannot be undone.")) {
      return;
    }
    try {
      setDeleteLoading(true);
      const token = localStorage.getItem("token");
      if (!token) {
        showError("Please sign in again.");
        router.push("/signin");
        return;
      }

      const res = await fetch("http://localhost:5000/api/profile/candidate", {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        const errorBody = await res.json().catch(() => null);
        throw new Error(errorBody?.error || errorBody?.message || "Failed to delete profile");
      }

      localStorage.removeItem("token");
      showSuccess("Your profile has been deleted.");
      router.push("/signin");
    } catch (err) {
      showError(err.message || "Failed to delete profile");
    } finally {
      setDeleteLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <p>Loading profile...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <p>Profile not found</p>
      </div>
    );
  }

  const ProfileField = ({ label, value }) => (
    <div
      style={{
        padding: "1rem",
        backgroundColor: "#fafafa",
        borderRadius: "0.5rem",
        marginBottom: "1rem",
      }}
    >
      <label
        style={{
          display: "block",
          fontSize: "0.875rem",
          fontWeight: "600",
          color: "#888",
          marginBottom: "0.5rem",
          textTransform: "uppercase",
          letterSpacing: "0.5px",
        }}
      >
        {label}
      </label>
      <p style={{ margin: 0, fontSize: "1rem", color: "#333", fontWeight: "500" }}>
        {value || "Not provided"}
      </p>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#f5f5f5" }}>
      {/* Header */}
      <div
        style={{
          backgroundColor: "white",
          padding: "20px 40px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <button
            onClick={() => router.back()}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "8px",
            }}
          >
            <ArrowLeft size={24} />
          </button>
          <h1 style={{ margin: 0, fontSize: "1.5rem", fontWeight: "bold" }}>
            My Profile
          </h1>
        </div>
        <button
          onClick={() => router.push("/candidate-profile/edit")}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            padding: "0.6rem 1.25rem",
            background: "rgba(255,255,255,0.6)",
            backdropFilter: "saturate(180%) blur(6px)",
            border: "1px solid rgba(255,255,255,0.6)",
            color: "#111827",
            borderRadius: "0.6rem",
            cursor: "pointer",
            fontWeight: "600",
            boxShadow: "0 6px 18px rgba(16,24,40,0.06)"
          }}
        >
          <Edit2 size={18} />
          Edit Profile
        </button>
      </div>

      {/* Main Content */}
      <div
        style={{
          maxWidth: "1000px",
          margin: "2rem auto",
          padding: "0 20px",
        }}
      >
        <div
          style={{
            backgroundColor: "white",
            borderRadius: "0.75rem",
            padding: "2rem",
            boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
          }}
        >
          {/* Personal Info Section */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Personal Information
            </h2>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "1rem",
              }}
            >
              <ProfileField label="Name" value={profile.name} />
              <ProfileField label="Email" value={profile.email} />
              <ProfileField label="Contact" value={profile.contact} />
            </div>
          </div>

          {/* Professional Info Section */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Professional Information
            </h2>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "1rem",
              }}
            >
              <ProfileField label="Job Role" value={profile.job_role} />
              <ProfileField label="Current Company" value={profile.current_company_name} />
              <ProfileField label="Current CTC (LPA)" value={profile.cctc} />
              <ProfileField label="Expected CTC (LPA)" value={profile.ectc} />
              <ProfileField label="Notice Period" value={profile.notice_period} />
              <ProfileField label="Offer in Hand" value={profile.offer_in_hand} />
            </div>
          </div>

          {/* Location Section */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Location
            </h2>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "1rem",
              }}
            >
              <ProfileField label="Current Location" value={profile.current_location} />
              <ProfileField label="Preferred Location" value={profile.preferred_location} />
            </div>
          </div>

          {/* Skills Section */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Skills
            </h2>
            <div style={{ display: "grid", gap: "1rem" }}>
              <ProfileField label="General Skills" value={profile.skills} />
              <ProfileField label="Technical Skills" value={profile.technical_skills} />
              <ProfileField label="Soft Skills" value={profile.soft_skills} />
            </div>
          </div>

          {/* Education & Qualification */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Education
            </h2>
            <div>
              <ProfileField label="Highest Qualification" value={profile.highest_qualification} />
            </div>
          </div>

          {/* Additional Information */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Additional Information
            </h2>
            <div style={{ display: "grid", gap: "1rem" }}>
              <ProfileField label="Address (as per Aadhaar)" value={profile.address_aadhaar} />
              <ProfileField label="Reason for Change" value={profile.reason_for_change} />
              <ProfileField label="LinkedIn Profile" value={profile.linkedin_profile} />
            </div>
          </div>

          {/* Resume & Skills Section */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Your Submitted Resume & Skills
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
              {/* Display Uploaded Resume */}
              <div>
                <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.75rem", color: "#334155" }}>
                  Uploaded Resume
                </label>
                {profile?.resume_file_path ? (
                  <a
                    href={`http://localhost:5000${profile.resume_file_path}`}
                    download
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "0.75rem",
                      padding: "1rem 1.25rem",
                      backgroundColor: "#16a34a",
                      color: "#fff",
                      border: "none",
                      borderRadius: "0.75rem",
                      cursor: "pointer",
                      fontWeight: "600",
                      textDecoration: "none",
                      fontSize: "0.95rem"
                    }}
                  >
                    📥 Download Resume
                  </a>
                ) : (
                  <p style={{ color: "#888", fontSize: "0.95rem", fontStyle: "italic" }}>No resume uploaded yet</p>
                )}
              </div>

              {/* Display Skills */}
              <div>
                <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.75rem", color: "#334155" }}>
                  Your Skills
                </label>
                {profile?.skills ? (
                  <div>
                    {typeof profile.skills === 'string' && profile.skills.startsWith('[') ? (
                      <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
                        {JSON.parse(profile.skills).map((skill) => (
                          <span
                            key={skill}
                            style={{
                              padding: "0.5rem 1rem",
                              backgroundColor: "#ff9d4d",
                              color: "#fff",
                              borderRadius: "999px",
                              fontSize: "0.85rem",
                              fontWeight: "600"
                            }}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    ) : Array.isArray(profile.skills) ? (
                      <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
                        {profile.skills.map((skill) => (
                          <span
                            key={skill}
                            style={{
                              padding: "0.5rem 1rem",
                              backgroundColor: "#ff9d4d",
                              color: "#fff",
                              borderRadius: "999px",
                              fontSize: "0.85rem",
                              fontWeight: "600"
                            }}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p style={{ color: "#888", fontSize: "0.95rem", fontStyle: "italic" }}>No skills added yet</p>
                    )}
                  </div>
                ) : (
                  <p style={{ color: "#888", fontSize: "0.95rem", fontStyle: "italic" }}>No skills added yet</p>
                )}
              </div>
            </div>
          </div>

          {/* Update Resume & Skills Section */}
          <div style={{ marginBottom: "2rem" }}>
            <h2
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                marginBottom: "1rem",
                borderBottom: "2px solid #ff9d4d",
                paddingBottom: "0.75rem",
                color: "#333",
              }}
            >
              Update Your Resume & Skills
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
              <div>
                <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.5rem", color: "#334155" }}>
                  Upload New Resume <span style={{ color: "#dc2626" }}>*</span>
                </label>
                <div
                  onClick={() => fileRef.current?.click()}
                  style={{
                    border: resume ? "2px solid #16a34a" : "2px dashed #cbd5e1",
                    borderRadius: "0.75rem",
                    padding: "1.75rem",
                    textAlign: "center",
                    cursor: "pointer",
                    backgroundColor: resume ? "#ecfdf5" : "#f8fafc",
                    transition: "all 0.3s"
                  }}
                >
                  <input
                    ref={fileRef}
                    type="file"
                    style={{ display: "none" }}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        if (file.size > 5 * 1024 * 1024) {
                          showError("File size must be under 5MB");
                          return;
                        }
                        setResume(file);
                        showSuccess("Resume uploaded!");
                      }
                    }}
                  />
                  {resume ? (
                    <div>
                      <CheckCircle2 style={{ width: "2rem", height: "2rem", margin: "0 auto 0.5rem", color: "#16a34a" }} />
                      <p style={{ color: "#16a34a", fontWeight: "700" }}>{resume.name}</p>
                      <p style={{ fontSize: "0.875rem", color: "#475569", marginTop: "0.25rem" }}>Click to change</p>
                    </div>
                  ) : (
                    <div>
                      <Upload style={{ width: "2rem", height: "2rem", margin: "0 auto 0.5rem", color: "#64748b" }} />
                      <p style={{ fontWeight: "700", color: "#0f172a" }}>Upload your resume</p>
                      <p style={{ fontSize: "0.875rem", color: "#64748b", marginTop: "0.25rem" }}>PDF or DOC only, under 5MB</p>
                    </div>
                  )}
                </div>
              </div>
              <div>
                <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.75rem", color: "#334155" }}>
                  Select Your Skills <span style={{ color: "#dc2626" }}>*</span>
                </label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "0.75rem", marginBottom: "1rem" }}>
                  {AVAILABLE_SKILLS.map((skill) => (
                    <button
                      key={skill}
                      onClick={() => toggleSkill(skill)}
                      style={{
                        padding: "0.6rem 1rem",
                        border: skills.includes(skill) ? "2px solid #fb923c" : "1px solid #cbd5e1",
                        backgroundColor: skills.includes(skill) ? "#fb923c" : "#fff",
                        color: skills.includes(skill) ? "#fff" : "#0f172a",
                        borderRadius: "999px",
                        cursor: "pointer",
                        fontSize: "0.85rem",
                        fontWeight: "600",
                        transition: "all 0.2s"
                      }}
                    >
                      {skill}
                    </button>
                  ))}
                </div>
                <div style={{ display: "flex", gap: "0.75rem" }}>
                  <input
                    value={customSkill}
                    onChange={(e) => setCustomSkill(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addSkill()}
                    placeholder="Add a custom skill"
                    style={{
                      flex: 1,
                      padding: "0.9rem 1rem",
                      border: "1px solid #cbd5e1",
                      borderRadius: "0.75rem",
                      fontSize: "0.95rem",
                      outline: "none"
                    }}
                  />
                  <button
                    onClick={addSkill}
                    style={{
                      padding: "0.9rem 1.25rem",
                      backgroundColor: "#ff9d4d",
                      border: "none",
                      borderRadius: "0.75rem",
                      color: "#fff",
                      fontWeight: "700",
                      cursor: "pointer"
                    }}
                  >
                    <Plus style={{ width: "1rem", height: "1rem" }} />
                  </button>
                </div>
                {skills.length > 0 && (
                  <div style={{ padding: "1rem", backgroundColor: "#ecfdf5", borderRadius: "0.75rem", border: "1px solid #bbf7d0", marginTop: "1rem" }}>
                    <p style={{ margin: 0, fontSize: "0.9rem", fontWeight: "600", color: "#166534" }}>Selected Skills ({skills.length})</p>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem", marginTop: "0.75rem" }}>
                      {skills.map((skill) => (
                        <div key={skill} style={{ display: "flex", alignItems: "center", gap: "0.4rem", padding: "0.45rem 0.8rem", backgroundColor: "#dcfce7", borderRadius: "0.75rem", color: "#166534", border: "1px solid #86efac" }}>
                          <span>{skill}</span>
                          <button onClick={() => removeSkill(skill)} style={{ background: "none", border: "none", cursor: "pointer", color: "#15803d" }}>
                            <X style={{ width: "0.9rem", height: "0.9rem" }} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <button
                onClick={submitVerification}
                disabled={verifyLoading || !resume || skills.length === 0}
                style={{
                  width: "100%",
                  padding: "1rem",
                  background: verifyLoading || !resume || skills.length === 0 ? "#e6e8eb" : "rgba(255,255,255,0.6)",
                  backdropFilter: "saturate(180%) blur(6px)",
                  border: "1px solid rgba(255,255,255,0.6)",
                  color: "#111827",
                  borderRadius: "0.75rem",
                  fontSize: "1rem",
                  fontWeight: "700",
                  cursor: verifyLoading || !resume || skills.length === 0 ? "not-allowed" : "pointer",
                  transition: "background-color 0.2s",
                  boxShadow: "0 8px 20px rgba(16,24,40,0.06)"
                }}
              >
                <CheckCircle2 style={{ width: "1rem", height: "1rem", marginRight: "0.5rem" }} />
                {verifyLoading ? "Updating..." : "Update Resume & Skills"}
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div
            style={{
              display: "flex",
              gap: "1rem",
              marginTop: "2rem",
              borderTop: "1px solid #f0f0f0",
              paddingTop: "1.5rem",
            }}
          >
            <button
              onClick={() => router.push("/candidate-profile/edit")}
              style={{
                flex: 1,
                padding: "1rem",
                background: "rgba(255,255,255,0.6)",
                backdropFilter: "saturate(180%) blur(6px)",
                border: "1px solid rgba(255,255,255,0.6)",
                color: "#111827",
                borderRadius: "0.5rem",
                fontSize: "1rem",
                fontWeight: "600",
                cursor: "pointer",
                boxShadow: "0 8px 20px rgba(16,24,40,0.06)"
              }}
            >
              Edit All Details
            </button>
            <button
              onClick={deleteProfile}
              disabled={deleteLoading}
              style={{
                padding: "1rem 1.25rem",
                backgroundColor: deleteLoading ? "#f87171" : "#dc2626",
                color: "#fff",
                border: "none",
                borderRadius: "0.5rem",
                fontSize: "1rem",
                fontWeight: "600",
                cursor: deleteLoading ? "not-allowed" : "pointer",
                opacity: deleteLoading ? 0.9 : 1,
              }}
            >
              {deleteLoading ? "Deleting..." : "Delete Profile"}
            </button>
            <button
              onClick={() => router.back()}
              style={{
                padding: "1rem 2rem",
                backgroundColor: "#f0f0f0",
                color: "#333",
                border: "none",
                borderRadius: "0.5rem",
                fontSize: "1rem",
                fontWeight: "600",
                cursor: "pointer",
              }}
            >
              Back
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
