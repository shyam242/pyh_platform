"use client";

import { useState, useRef, useEffect } from "react";
import { Upload, CheckCircle2, Plus, X, Edit2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { showSuccess, showError } from "@/utils/toast";

const AVAILABLE_SKILLS = ["React", "Node.js", "Python", "Java", "AWS", "UI/UX", "TypeScript", "MongoDB"];

export default function CandidateDashboard() {
  const router = useRouter();
  const [resume, setResume] = useState(null);
  const [skills, setSkills] = useState([]);
  const [customSkill, setCustomSkill] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [jobs, setJobs] = useState([]);
  const [jobLoading, setJobLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [imageLoading, setImageLoading] = useState(false);
  const [appliedCount, setAppliedCount] = useState(0);
  const [filterRole, setFilterRole] = useState("");
  const [filterExperience, setFilterExperience] = useState("");
  const [filterLocation, setFilterLocation] = useState("");
  const [filterSalary, setFilterSalary] = useState("");
  const fileRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      window.location.href = "/signin";
      return;
    }
    fetchDashboardData(token);
  }, []);

  const fetchDashboardData = async (token) => {
    await Promise.all([fetchJobs(token), fetchProfile(token), fetchAppliedCount(token)]);
  };

  const fetchJobs = async (token) => {
    setJobLoading(true);
    try {
      const res = await fetch("http://localhost:5000/api/jobs", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setJobs(Array.isArray(data) ? data : []);
      } else {
        console.warn("Failed to load jobs", res.status);
      }
    } catch (err) {
      console.error("Failed to load jobs", err);
    } finally {
      setJobLoading(false);
    }
  };

  const fetchProfile = async (token) => {
    try {
      const res = await fetch("http://localhost:5000/api/profile/user", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
        setImagePreview(data.image_url || null);
      }
    } catch (err) {
      console.error("Failed to fetch profile", err);
    }
  };

  const fetchAppliedCount = async (token) => {
    try {
      const res = await fetch("http://localhost:5000/api/jobs/applied/count", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setAppliedCount(data.appliedCount || 0);
      }
    } catch (err) {
      console.error("Failed to fetch applied count", err);
    }
  };

  const toggleSkill = (s) => {
    setSkills((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  };

  const addSkill = () => {
    if (customSkill.trim() && !skills.includes(customSkill.trim())) {
      setSkills([...skills, customSkill.trim()]);
      setCustomSkill("");
    }
  };

  const removeSkill = (s) => {
    setSkills(skills.filter((x) => x !== s));
  };

  const handleImageSelect = (file) => {
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      showError("Profile picture must be smaller than 2MB");
      return;
    }
    setSelectedImage(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const uploadProfileImage = async () => {
    if (!selectedImage) {
      showError("Select an image first");
      return;
    }
    setImageLoading(true);
    try {
      const token = localStorage.getItem("token");
      const fd = new FormData();
      fd.append("image", selectedImage);

      const res = await fetch("http://localhost:5000/api/profile/avatar", {
        method: "PUT",
        headers: { Authorization: `Bearer ${token}` },
        body: fd,
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to upload profile image");
      }

      const data = await res.json();
      setProfile(data.user);
      setImagePreview(data.user.image_url || null);
      setSelectedImage(null);
      showSuccess("Profile picture updated successfully");
    } catch (err) {
      showError(err.message || "Failed to upload profile image");
    } finally {
      setImageLoading(false);
    }
  };

  const getCardValue = (label) => {
    if (label === "Total Jobs") return jobs.length;
    if (label === "Applied") return appliedCount;
    if (label === "Profile Status") return profile?.verified ? "Verified" : "Pending";
    if (label === "Skills Added") {
      if (profile?.skills) {
        try {
          const skillsArray = typeof profile.skills === 'string' ? JSON.parse(profile.skills) : profile.skills;
          return Array.isArray(skillsArray) ? skillsArray.length : 0;
        } catch {
          return 0;
        }
      }
      return skills.length;
    }
    return "-";
  };

  const submit = async () => {
    if (!resume) return showError("Upload resume first");
    if (skills.length === 0) return showError("Select at least one skill");

    setLoading(true);

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        showError("Please sign in again.");
        window.location.href = "/signin";
        return;
      }
      const fd = new FormData();
      fd.append("resume", resume);
      fd.append("skills", JSON.stringify(skills));

      const res = await fetch("http://localhost:5000/api/profile/verify", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: fd
      });

      if (!res.ok) {
        const rawText = await res.text();
        let parsed;
        try {
          parsed = JSON.parse(rawText);
        } catch (e) {
          parsed = null;
        }
        const bodyText = parsed?.message || parsed?.error || rawText;
        if (res.status === 404 || res.status === 405 || /Cannot POST/i.test(rawText) || /Cannot GET/i.test(rawText)) {
          throw new Error(
            `Backend route not found: POST http://localhost:5000/api/profile/verify. Confirm the server defines this endpoint and accepts POST requests.`
          );
        }
        throw new Error(bodyText || `Verification failed (status ${res.status})`);
      }

      showSuccess("Profile verified successfully!");
      setSubmitted(true);
      const tokenRef = localStorage.getItem("token");
      if (tokenRef) await fetchProfile(tokenRef);
      setTimeout(() => setSubmitted(false), 3000);
    } catch (err) {
      showError(err.message || "Verification failed");
    } finally {
      setLoading(false);
    }
  };

  const handleJobAction = (job) => {
    const jobId = job.id || job._id;
    if (jobId) {
      router.push(`/jobs/${jobId}`);
    } else {
      showError("Unable to open job details");
    }
  };

  const getFilteredJobs = () => {
    return jobs.filter((job) => {
      if (filterRole && !job.job_title?.toLowerCase().includes(filterRole.toLowerCase())) return false;
      if (filterExperience && job.experience_required?.toLowerCase().indexOf(filterExperience.toLowerCase()) === -1) return false;
      if (filterLocation && !job.location?.toLowerCase().includes(filterLocation.toLowerCase())) return false;
      if (filterSalary) {
        const salaryStr = (job.salary_range || "").toLowerCase();
        if (!salaryStr.includes(filterSalary.toLowerCase())) return false;
      }
      return true;
    });
  };

  const filteredJobs = getFilteredJobs();

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#f8fafc", color: "#0f172a", padding: "3rem 1.5rem" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        {/* NAVBAR */}
        <nav style={{
          backgroundColor: "#ffffff",
          borderBottom: "1px solid #e5e7eb",
          padding: "0.75rem 0",
          boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
          marginBottom: "1rem"
        }}>
          <div style={{
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "0 1.5rem",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              {/* left intentionally minimal - no heading */}
            </div>

            <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
              <button
                onClick={() => router.push("/candidate-profile")}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.5rem",
                  padding: "0.55rem 1rem",
                  background: "rgba(255,255,255,0.6)",
                  backdropFilter: "saturate(180%) blur(6px)",
                  border: "1px solid rgba(255,255,255,0.6)",
                  color: "#111827",
                  borderRadius: "0.6rem",
                  cursor: "pointer",
                  fontWeight: 600,
                  boxShadow: "0 6px 18px rgba(16,24,40,0.06)"
                }}
              >
                <Edit2 size={16} />
                Edit Profile
              </button>

              <button
                onClick={() => { localStorage.removeItem("token"); window.location.href = "/signin"; }}
                style={{
                  padding: "0.55rem 1rem",
                  backgroundColor: "#ef4444",
                  color: "#fff",
                  border: "none",
                  borderRadius: "0.6rem",
                  cursor: "pointer",
                  fontWeight: 600,
                  boxShadow: "0 6px 18px rgba(239,68,68,0.12)"
                }}
              >
                Logout
              </button>
            </div>
          </div>
        </nav>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem", marginBottom: "2rem" }}>
          {["Total Jobs", "Applied", "Profile Status", "Skills Added"].map((label) => (
            <div key={label} style={{ backgroundColor: "#ff9d4d", borderRadius: "1rem", padding: "1.5rem", color: "#fff", boxShadow: "0 12px 30px rgba(255,157,77,0.12)" }}>
              <p style={{ margin: 0, opacity: 0.85, fontSize: "0.95rem" }}>{label}</p>
              <p style={{ margin: "0.75rem 0 0", fontSize: "2.25rem", fontWeight: "700" }}>{getCardValue(label)}</p>
            </div>
          ))}
        </div>


        <div style={{ marginBottom: "1.5rem", display: "flex", justifyContent: "space-between", alignItems: "center", gap: "1rem" }}>
          <div>
            <h2 style={{ margin: 0, fontSize: "1.75rem", fontWeight: "700", color: "#0f172a" }}>Open Jobs</h2>
            <p style={{ margin: "0.5rem 0 0", color: "#64748b" }}>Browse the latest openings that can match your skills.</p>
          </div>
          <div style={{ color: "#475569", fontSize: "0.95rem" }}>{jobLoading ? "Loading jobs..." : `${filteredJobs.length} of ${jobs.length} jobs`}</div>
        </div>

        <div style={{ backgroundColor: "#fff", borderRadius: "1rem", border: "1px solid #e2e8f0", padding: "1.5rem", marginBottom: "1.5rem", boxShadow: "0 1px 3px rgba(15,23,42,0.04)" }}>
          <h3 style={{ margin: "0 0 1rem", fontSize: "1.125rem", fontWeight: "700", color: "#0f172a" }}>Filter Jobs</h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.5rem", color: "#334155" }}>
                Job Role
              </label>
              <input
                type="text"
                placeholder="e.g., React Developer"
                value={filterRole}
                onChange={(e) => setFilterRole(e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #cbd5e1",
                  borderRadius: "0.5rem",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.5rem", color: "#334155" }}>
                Experience
              </label>
              <input
                type="text"
                placeholder="e.g., 2-3 years"
                value={filterExperience}
                onChange={(e) => setFilterExperience(e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #cbd5e1",
                  borderRadius: "0.5rem",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.5rem", color: "#334155" }}>
                Location
              </label>
              <input
                type="text"
                placeholder="e.g., New York, Remote"
                value={filterLocation}
                onChange={(e) => setFilterLocation(e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #cbd5e1",
                  borderRadius: "0.5rem",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
              />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "0.875rem", fontWeight: "600", marginBottom: "0.5rem", color: "#334155" }}>
                Salary Range
              </label>
              <input
                type="text"
                placeholder="e.g., 50L - 75L"
                value={filterSalary}
                onChange={(e) => setFilterSalary(e.target.value)}
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  border: "1px solid #cbd5e1",
                  borderRadius: "0.5rem",
                  fontSize: "0.9rem",
                  outline: "none"
                }}
              />
            </div>
          </div>
          {(filterRole || filterExperience || filterLocation || filterSalary) && (
            <button
              onClick={() => {
                setFilterRole("");
                setFilterExperience("");
                setFilterLocation("");
                setFilterSalary("");
              }}
              style={{
                marginTop: "1rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#f5f5f5",
                border: "1px solid #cbd5e1",
                borderRadius: "0.5rem",
                cursor: "pointer",
                fontSize: "0.9rem",
                fontWeight: "600",
                color: "#475569"
              }}
            >
              Clear Filters
            </button>
          )}
        </div>

        <div style={{ display: "grid", gap: "1.5rem" }}>
          {jobLoading ? (
            <div style={{ padding: "2rem", backgroundColor: "#fff", borderRadius: "1rem", border: "1px solid #e2e8f0", textAlign: "center", color: "#64748b" }}>
              Loading available jobs...
            </div>
          ) : filteredJobs.length === 0 ? (
            <div style={{ padding: "2rem", backgroundColor: "#fff", borderRadius: "1rem", border: "1px solid #e2e8f0", textAlign: "center", color: "#64748b" }}>
              {jobs.length === 0 ? "No job openings are available right now. Check back soon." : "No jobs match your filters. Try adjusting your criteria."}
            </div>
          ) : (
            filteredJobs.map((job) => (
              <div key={job.id || job._id || job.job_title} style={{ backgroundColor: "#fff", borderRadius: "1rem", border: "1px solid #e2e8f0", padding: "1.5rem", boxShadow: "0 1px 3px rgba(15,23,42,0.04)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", alignItems: "flex-start", gap: "1rem" }}>
                  <div style={{ flex: 1, minWidth: "220px" }}>
                    <h3 style={{ margin: "0 0 0.5rem", fontSize: "1.25rem", fontWeight: "700", color: "#0f172a" }}>{job.job_title || job.title || "Untitled Role"}</h3>
                    <p style={{ margin: 0, color: "#475569" }}>{job.department || job.department_name || "General"}</p>
                  </div>
                  <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
                    <span style={{ padding: "0.5rem 0.75rem", borderRadius: "999px", backgroundColor: "#eef2ff", color: "#3730a3", fontSize: "0.85rem", fontWeight: "600" }}>{job.location || "Remote"}</span>
                    <span style={{ padding: "0.5rem 0.75rem", borderRadius: "999px", backgroundColor: "#f7fee7", color: "#166534", fontSize: "0.85rem", fontWeight: "600" }}>{job.job_type || job.type || "Full-time"}</span>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: "0.75rem", marginTop: "1rem", color: "#475569" }}>
                  <div style={{ padding: "1rem", borderRadius: "0.75rem", backgroundColor: "#f8fafc" }}>
                    <p style={{ margin: 0, fontSize: "0.75rem", fontWeight: "600", textTransform: "uppercase", letterSpacing: "0.04em" }}>Experience</p>
                    <p style={{ margin: "0.5rem 0 0", fontWeight: "700", color: "#0f172a" }}>{job.experience_required || job.experience || "Not specified"}</p>
                  </div>
                  <div style={{ padding: "1rem", borderRadius: "0.75rem", backgroundColor: "#f8fafc" }}>
                    <p style={{ margin: 0, fontSize: "0.75rem", fontWeight: "600", textTransform: "uppercase", letterSpacing: "0.04em" }}>Salary</p>
                    <p style={{ margin: "0.5rem 0 0", fontWeight: "700", color: "#0f172a" }}>{job.salary_range || job.salary || "Not disclosed"}</p>
                  </div>
                </div>

                <p style={{ margin: "1rem 0 0", color: "#475569", lineHeight: "1.75" }}>
                  {(job.job_description || job.description || "No description available.").slice(0, 180)}
                  {(job.job_description || job.description || "").length > 180 ? "..." : ""}
                </p>

                <div style={{ marginTop: "1.25rem", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
                  <span style={{ color: "#64748b", fontSize: "0.9rem" }}>Posted {job.posted_at || job.postedOn || "recently"}</span>
                  <button
                    onClick={() => handleJobAction(job)}
                    style={{
                      padding: "0.9rem 1.25rem",
                      backgroundColor: "#ff9d4d",
                      color: "#fff",
                      border: "none",
                      borderRadius: "0.75rem",
                      cursor: "pointer",
                      fontWeight: "700"
                    }}
                  >
                    View Details
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
